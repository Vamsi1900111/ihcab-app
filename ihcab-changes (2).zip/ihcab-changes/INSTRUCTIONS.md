# iHcab App — Change Instructions

---

## ✅ CHANGE 1: Remove Lovable Icon

Replace root `index.html` with the provided one. Done.

---

## ✅ CHANGE 2: Real-time WhatsApp-style Calls

### Step A — Run SQL
Supabase Dashboard → SQL Editor → run:
`supabase/migrations/20250326_add_calls_and_email_tracking.sql`

### Step B — Add 4 new files to repo
```
src/hooks/useWebRTCCall.ts
src/hooks/useCallUsers.ts
src/components/CallFeature.tsx
src/components/CallButton.tsx
```

### Step C — One line in your chat component
Find your chat header/page file and add:

```tsx
import CallButton from "@/components/CallButton";

// In your JSX (e.g. next to the user name):
<CallButton />
```

`<CallButton>` auto-detects Vamsi/Bhavya from Supabase auth.
Recognises "asthipanjaram" = Vamsi, "bachii" = Bhavya automatically.

---

## ✅ CHANGE 3: Email Notification (unread after 1 min)

### Step A — Deploy Edge Function
```bash
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase functions deploy check-unread-messages
```

### Step B — Enable pg_cron & schedule
1. Supabase Dashboard → Database → Extensions → enable pg_cron
2. SQL Editor → run `SETUP_CRON_JOB.sql`
   (replace YOUR_SUPABASE_PROJECT_REF and YOUR_ANON_KEY)

### Step C — Mark messages read when Vamsi opens chat
In your chat component, add:

```ts
// Call when conversation is opened or messages are viewed:
await supabase
  .from('messages')
  .update({ read_at: new Date().toISOString() })
  .eq('sender_id', bhavyaUserId)
  .is('read_at', null);
```

---

## File Map

```
ihcab-app/
├── index.html                                            ← REPLACE
├── src/
│   ├── components/
│   │   ├── CallFeature.tsx                               ← ADD NEW
│   │   └── CallButton.tsx                                ← ADD NEW
│   └── hooks/
│       ├── useWebRTCCall.ts                              ← ADD NEW
│       └── useCallUsers.ts                               ← ADD NEW
└── supabase/
    ├── functions/
    │   └── check-unread-messages/
    │       └── index.ts                                  ← ADD NEW
    └── migrations/
        ├── 20250326_add_calls_and_email_tracking.sql     ← RUN IN SQL EDITOR
        └── SETUP_CRON_JOB.sql                            ← RUN IN SQL EDITOR

Your chat component (wherever it lives):
  → import CallButton from "@/components/CallButton";
  → <CallButton />
```
