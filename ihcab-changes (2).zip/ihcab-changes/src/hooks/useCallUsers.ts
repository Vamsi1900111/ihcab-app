// src/hooks/useCallUsers.ts
// Automatically figures out who is Vamsi and who is Bhavya
// from the Supabase auth session — no hardcoded IDs needed.

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface CallUser {
  id: string;
  name: string;
  email?: string;
}

export function useCallUsers() {
  const [currentUser, setCurrentUser] = useState<CallUser | null>(null);
  const [remoteUser, setRemoteUser] = useState<CallUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function detectUsers() {
      // 1. Get the currently logged-in user from Supabase auth
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      // 2. Try to get display name from profiles table (common Supabase pattern)
      //    Falls back to email prefix if no profiles table exists
      let currentName = user.email?.split("@")[0] ?? user.id;
      let remoteName = "";
      let remoteId = "";

      try {
        // Try profiles table first
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, username, full_name, display_name, name")
          .limit(10);

        if (profiles && profiles.length > 0) {
          // Find current user's profile
          const myProfile = profiles.find((p: any) => p.id === user.id);
          if (myProfile) {
            currentName =
              myProfile.username ||
              myProfile.full_name ||
              myProfile.display_name ||
              myProfile.name ||
              currentName;
          }

          // The "other" user is any profile that isn't the current user
          const otherProfile = profiles.find((p: any) => p.id !== user.id);
          if (otherProfile) {
            remoteId = otherProfile.id;
            remoteName =
              otherProfile.username ||
              otherProfile.full_name ||
              otherProfile.display_name ||
              otherProfile.name ||
              "Other User";
          }
        }
      } catch {
        // profiles table might not exist — fall through to users table
      }

      // 3. If no profiles table, try users table
      if (!remoteId) {
        try {
          const { data: users } = await supabase
            .from("users")
            .select("id, username, name, email")
            .neq("id", user.id)
            .limit(1);

          if (users && users.length > 0) {
            remoteId = users[0].id;
            remoteName =
              users[0].username ||
              users[0].name ||
              users[0].email?.split("@")[0] ||
              "Other User";
          }
        } catch {
          // no users table either
        }
      }

      // 4. Determine Vamsi / Bhavya by checking the name/username
      //    Supports both "asthipanjaram" (Vamsi) and "bachii" (Bhavya) as identifiers
      const vamsiKeywords = ["vamsi", "asthipanjaram"];
      const bhavyaKeywords = ["bhavya", "bachii", "bachi"];

      const nameLC = currentName.toLowerCase();
      if (vamsiKeywords.some((k) => nameLC.includes(k))) {
        currentName = "Vamsi";
      } else if (bhavyaKeywords.some((k) => nameLC.includes(k))) {
        currentName = "Bhavya";
      }

      const remoteNameLC = remoteName.toLowerCase();
      if (vamsiKeywords.some((k) => remoteNameLC.includes(k))) {
        remoteName = "Vamsi";
      } else if (bhavyaKeywords.some((k) => remoteNameLC.includes(k))) {
        remoteName = "Bhavya";
      }

      setCurrentUser({ id: user.id, name: currentName, email: user.email });
      setRemoteUser(remoteId ? { id: remoteId, name: remoteName } : null);
      setLoading(false);
    }

    detectUsers();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      detectUsers();
    });

    return () => subscription.unsubscribe();
  }, []);

  return { currentUser, remoteUser, loading };
}
