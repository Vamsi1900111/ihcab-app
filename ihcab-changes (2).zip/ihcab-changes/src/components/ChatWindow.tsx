import React, { useState, useRef, useEffect } from 'react';
import { Message } from './ChatInterface';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  ArrowLeft, Phone, Video, MoreVertical, Paperclip, 
  Smile, Mic, Send, X, Edit2, Trash2, Reply, Languages,
  PhoneOff, MicOff, VideoOff, PhoneIncoming
} from "lucide-react";
import { format } from "date-fns";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import MessageTicks from './MessageTicks';
import VoiceNoteRecorder from './VoiceNoteRecorder';
import VoiceNotePlayer from './VoiceNotePlayer';
import { supabase } from "@/integrations/supabase/client";
import { useWebRTCCall } from "@/hooks/useWebRTCCall";

interface ChatWindowProps {
  chatPartner: string;
  messages: Message[];
  currentUser: 'boy' | 'girl';
  onBack: () => void;
  onSendMessage: (text: string, type?: 'text' | 'image' | 'voice', replyTo?: Message, voiceDuration?: number) => void;
  onDeleteMessage: (id: string) => void;
  onEditMessage: (id: string, newText: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ 
  chatPartner, messages, currentUser, onBack, onSendMessage, onDeleteMessage, onEditMessage 
}) => {
  const [inputText, setInputText] = useState("");
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [translatingId, setTranslatingId] = useState<string | null>(null);

  // ─── Real user IDs from Supabase auth ────────────────────────────────────
  const [myUserId, setMyUserId] = useState<string>("");
  const [partnerUserId, setPartnerUserId] = useState<string>("");

  useEffect(() => {
    async function resolveUserIds() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setMyUserId(user.id);

      // Find the other user's ID — try profiles table first, then users table
      const vamsiKeywords = ["vamsi", "asthipanjaram"];
      const bhavyaKeywords = ["bhavya", "bachii", "bachi"];

      try {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, username, full_name, display_name, name")
          .neq("id", user.id)
          .limit(5);

        if (profiles && profiles.length > 0) {
          const match = profiles.find((p: any) => {
            const n = (p.username || p.full_name || p.display_name || p.name || "").toLowerCase();
            const partnerLC = chatPartner.toLowerCase();
            return n.includes(partnerLC) ||
              (bhavyaKeywords.some(k => partnerLC.includes(k)) && bhavyaKeywords.some(k => n.includes(k))) ||
              (vamsiKeywords.some(k => partnerLC.includes(k)) && vamsiKeywords.some(k => n.includes(k)));
          }) || profiles[0];
          setPartnerUserId(match.id);
        }
      } catch {
        // fall back to users table
        try {
          const { data: users } = await supabase
            .from("users")
            .select("id, username, name, email")
            .neq("id", user.id)
            .limit(1);
          if (users && users.length > 0) setPartnerUserId(users[0].id);
        } catch { /* ignore */ }
      }
    }
    resolveUserIds();
  }, [chatPartner]);

  // ─── WebRTC call hook ─────────────────────────────────────────────────────
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  const {
    callStatus,
    isMuted,
    isVideoOff,
    formattedDuration,
    startCall: startWebRTCCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
  } = useWebRTCCall({
    currentUserId: myUserId,
    remoteUserId: partnerUserId,
    localVideoRef,
    remoteVideoRef,
    audioOnly: false,
  });

  const handleCallStart = (type: 'voice' | 'video') => {
    if (!myUserId || !partnerUserId) {
      toast.error("Could not identify users. Please refresh and try again.");
      return;
    }
    startWebRTCCall();
  };

  // ─── Mark messages as read (for email notification feature) ──────────────
  useEffect(() => {
    const unreadIds = messages
      .filter(m => m.sender !== currentUser && !(m as any).read_at)
      .map(m => m.id);

    if (unreadIds.length === 0) return;

    supabase
      .from('messages')
      .update({ read_at: new Date().toISOString() })
      .in('id', unreadIds)
      .then(({ error }) => {
        if (error) console.warn("Could not mark messages as read:", error.message);
      });
  }, [messages, currentUser]);

  // ─── Scroll to bottom ─────────────────────────────────────────────────────
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    if (editingId) {
      onEditMessage(editingId, inputText);
      setEditingId(null);
    } else {
      onSendMessage(inputText, 'text', replyingTo || undefined);
    }
    setInputText("");
    setReplyingTo(null);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = `${Date.now()}-${file.name}`;
    const { error } = await supabase.storage
      .from('chat-media')
      .upload(fileName, file);

    if (error) {
      toast.error("Failed to upload image");
      console.error(error);
      return;
    }

    const { data: urlData } = supabase.storage
      .from('chat-media')
      .getPublicUrl(fileName);

    onSendMessage(urlData.publicUrl, 'image');
  };

  const handleVoiceSend = async (audioBlob: string, duration: number) => {
    try {
      const response = await fetch(audioBlob);
      const blob = await response.blob();
      const fileName = `voice-${Date.now()}.webm`;

      const { error } = await supabase.storage
        .from('chat-media')
        .upload(fileName, blob, { contentType: 'audio/webm' });

      if (error) {
        toast.error("Failed to upload voice note");
        console.error(error);
        return;
      }

      const { data: urlData } = supabase.storage
        .from('chat-media')
        .getPublicUrl(fileName);

      onSendMessage(urlData.publicUrl, 'voice', replyingTo || undefined, duration);
    } catch (err) {
      toast.error("Failed to send voice note");
      console.error(err);
    }
    setIsRecordingVoice(false);
    setReplyingTo(null);
  };

  const translateMessage = async (msgId: string, text: string) => {
    setTranslatingId(msgId);
    try {
      const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=autodetect|en`);
      const data = await res.json();
      if (data.responseStatus === 200 && data.responseData?.translatedText) {
        toast.success(`Translation: ${data.responseData.translatedText}`, { duration: 8000 });
      } else {
        toast.error("Could not translate this message");
      }
    } catch {
      toast.error("Translation failed");
    }
    setTranslatingId(null);
  };

  const isCallActive = callStatus !== 'idle' && callStatus !== 'ended' && callStatus !== 'rejected' && callStatus !== 'error';

  return (
    <div className="flex flex-col h-full relative">
      {/* ─── Chat Header ──────────────────────────────────────────────────── */}
      <div className="bg-secondary p-3 flex items-center justify-between border-b border-border z-10">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Avatar>
            <AvatarFallback>{chatPartner[0]}</AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="font-semibold">{chatPartner}</span>
            <span className="text-xs text-muted-foreground">
              {callStatus === 'active' ? `In call · ${formattedDuration}` : 'Online'}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {/* Voice Call Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => handleCallStart('voice')}
            disabled={isCallActive}
            className={callStatus === 'active' ? 'text-green-500' : ''}
          >
            <Phone className="h-5 w-5" />
          </Button>
          {/* Video Call Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => handleCallStart('video')}
            disabled={isCallActive}
            className={callStatus === 'active' ? 'text-green-500' : ''}
          >
            <Video className="h-5 w-5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => toast.info("Contact info")}>View Contact</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.info("Search")}>Search</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.info("Wallpaper")}>Wallpaper</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive" onClick={() => toast.info("Blocked")}>Block</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* ─── Messages Area ────────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')] bg-repeat bg-fixed opacity-95">
        {messages.map((msg) => {
          const isOwn = msg.sender === currentUser;
          return (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn("flex w-full", isOwn ? "justify-end" : "justify-start")}
            >
              <div className={cn(
                "max-w-[80%] rounded-lg p-3 shadow-sm relative group",
                isOwn ? "bg-chat-own text-primary-foreground rounded-tr-none" : "bg-chat-peer text-foreground rounded-tl-none",
                msg.isDeleted && "italic opacity-70"
              )}>
                {msg.replyTo && (
                  <div className="mb-2 p-2 rounded bg-black/20 text-xs border-l-4 border-primary/50 truncate">
                    <span className="font-bold block opacity-70">
                      {msg.replyTo.sender === currentUser ? "You" : chatPartner}
                    </span>
                    {msg.replyTo.type === 'image' ? '📷 Photo' : msg.replyTo.type === 'voice' ? '🎤 Voice note' : msg.replyTo.text}
                  </div>
                )}

                {msg.type === 'image' ? (
                  <img src={msg.text} alt="Shared" className="rounded-md max-w-full h-auto max-h-[300px]" />
                ) : msg.type === 'voice' ? (
                  <VoiceNotePlayer src={msg.text} duration={msg.voiceDuration} />
                ) : (
                  <p className="text-sm md:text-base leading-relaxed break-words">{msg.text}</p>
                )}

                <div className="flex items-center justify-end gap-1 mt-1 opacity-70">
                  {msg.isEdited && <span className="text-[10px] mr-1">edited</span>}
                  <span className="text-[10px]">{format(msg.timestamp, 'HH:mm')}</span>
                  {isOwn && <MessageTicks status={msg.status} />}
                </div>

                {!msg.isDeleted && (
                  <div className={cn(
                    "absolute top-0 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 rounded-full shadow-md",
                    isOwn ? "-left-10" : "-right-10"
                  )}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => setReplyingTo(msg)}>
                          <Reply className="h-4 w-4 mr-2" /> Reply
                        </DropdownMenuItem>
                        {msg.type === 'text' && (
                          <DropdownMenuItem
                            onClick={() => translateMessage(msg.id, msg.text)}
                            disabled={translatingId === msg.id}
                          >
                            <Languages className="h-4 w-4 mr-2" />
                            {translatingId === msg.id ? 'Translating...' : 'Translate to English'}
                          </DropdownMenuItem>
                        )}
                        {isOwn && (
                          <>
                            {msg.type === 'text' && (
                              <DropdownMenuItem onClick={() => {
                                setInputText(msg.text);
                                setEditingId(msg.id);
                              }}>
                                <Edit2 className="h-4 w-4 mr-2" /> Edit
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => onDeleteMessage(msg.id)}
                            >
                              <Trash2 className="h-4 w-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* ─── Input Area ───────────────────────────────────────────────────── */}
      <div className="bg-secondary p-2 flex flex-col gap-2 z-20">
        <AnimatePresence>
          {replyingTo && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-background/50 p-2 rounded-t-lg flex justify-between items-center border-l-4 border-primary"
            >
              <div className="text-sm">
                <span className="font-bold text-primary text-xs block">
                  Replying to {replyingTo.sender === currentUser ? "You" : chatPartner}
                </span>
                <span className="text-muted-foreground text-xs truncate max-w-[200px] block">
                  {replyingTo.type === 'image' ? '📷 Photo' : replyingTo.type === 'voice' ? '🎤 Voice note' : replyingTo.text}
                </span>
              </div>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setReplyingTo(null)}>
                <X className="h-4 w-4" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-2">
          {isRecordingVoice ? (
            <VoiceNoteRecorder
              onSend={handleVoiceSend}
              onCancel={() => setIsRecordingVoice(false)}
            />
          ) : (
            <>
              <Button variant="ghost" size="icon" className="shrink-0">
                <Smile className="h-6 w-6 text-muted-foreground" />
              </Button>
              <Button variant="ghost" size="icon" className="shrink-0" onClick={() => fileInputRef.current?.click()}>
                <Paperclip className="h-6 w-6 text-muted-foreground" />
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleFileUpload}
              />
              <Input
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={editingId ? "Edit message..." : "Type a message"}
                className="flex-1 bg-background border-none focus-visible:ring-1 focus-visible:ring-primary"
              />
              {inputText ? (
                <Button size="icon" onClick={handleSend} className="bg-primary hover:bg-primary/90 rounded-full shrink-0">
                  <Send className="h-5 w-5" />
                </Button>
              ) : (
                <Button variant="ghost" size="icon" className="shrink-0" onClick={() => setIsRecordingVoice(true)}>
                  <Mic className="h-6 w-6 text-muted-foreground" />
                </Button>
              )}
            </>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════ */}
      {/* REAL CALL OVERLAYS (replaces fake Dialog)                          */}
      {/* ═══════════════════════════════════════════════════════════════════ */}

      {/* Incoming call (ringing) */}
      <AnimatePresence>
        {callStatus === 'ringing' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
          >
            <div className="bg-secondary rounded-2xl p-8 text-center shadow-2xl max-w-xs w-full mx-4">
              <div className="relative mx-auto w-24 h-24 mb-6">
                <span className="absolute inset-0 rounded-full bg-green-500/30 animate-ping" />
                <span className="absolute inset-2 rounded-full bg-green-500/40 animate-ping" style={{ animationDelay: '150ms' }} />
                <Avatar className="relative z-10 w-24 h-24 border-4 border-green-500">
                  <AvatarFallback className="text-3xl">{chatPartner[0]}</AvatarFallback>
                </Avatar>
              </div>
              <p className="text-muted-foreground text-sm mb-1">Incoming call</p>
              <h2 className="text-2xl font-bold mb-6">{chatPartner}</h2>
              <div className="flex justify-center gap-10">
                <div className="flex flex-col items-center gap-1">
                  <Button size="icon" variant="destructive" className="h-16 w-16 rounded-full" onClick={rejectCall}>
                    <PhoneOff className="h-7 w-7" />
                  </Button>
                  <span className="text-xs text-muted-foreground">Decline</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <Button size="icon" className="h-16 w-16 rounded-full bg-green-500 hover:bg-green-600 animate-pulse" onClick={answerCall}>
                    <Phone className="h-7 w-7" />
                  </Button>
                  <span className="text-xs text-muted-foreground">Answer</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Outgoing call (calling...) */}
      <AnimatePresence>
        {callStatus === 'calling' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
          >
            <div className="bg-secondary rounded-2xl p-8 text-center shadow-2xl max-w-xs w-full mx-4">
              <div className="relative mx-auto w-24 h-24 mb-6">
                <span className="absolute inset-0 rounded-full bg-blue-500/30 animate-ping" />
                <Avatar className="relative z-10 w-24 h-24 border-4 border-blue-500">
                  <AvatarFallback className="text-3xl">{chatPartner[0]}</AvatarFallback>
                </Avatar>
              </div>
              <h2 className="text-2xl font-bold mb-2">{chatPartner}</h2>
              <p className="text-muted-foreground mb-8 animate-pulse">Calling...</p>
              <Button size="icon" variant="destructive" className="h-16 w-16 rounded-full" onClick={endCall}>
                <PhoneOff className="h-7 w-7" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active call (full-screen video/audio) */}
      <AnimatePresence>
        {callStatus === 'active' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black flex flex-col"
          >
            {/* Remote video */}
            <video ref={remoteVideoRef} autoPlay playsInline className="flex-1 w-full object-cover" />

            {/* Local video (picture-in-picture) */}
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className="absolute top-4 right-4 w-28 h-40 rounded-xl object-cover border-2 border-white shadow-xl"
            />

            {/* Audio-only fallback (shown when no remote video) */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center opacity-0 peer-empty:opacity-100">
                <Avatar className="w-28 h-28 mx-auto mb-4 border-4 border-white">
                  <AvatarFallback className="text-5xl">{chatPartner[0]}</AvatarFallback>
                </Avatar>
                <h2 className="text-white text-2xl font-bold">{chatPartner}</h2>
              </div>
            </div>

            {/* Duration */}
            <div className="absolute top-4 left-4 bg-black/50 rounded-full px-3 py-1">
              <span className="text-white text-sm font-mono">{formattedDuration}</span>
            </div>

            {/* Controls */}
            <div className="absolute bottom-10 left-0 right-0 flex justify-center gap-6">
              <Button
                size="icon"
                className={cn("h-14 w-14 rounded-full", isMuted ? "bg-red-500 hover:bg-red-600" : "bg-gray-600 hover:bg-gray-700")}
                onClick={toggleMute}
              >
                {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </Button>

              <Button
                size="icon"
                variant="destructive"
                className="h-16 w-16 rounded-full"
                onClick={endCall}
              >
                <PhoneOff className="h-7 w-7" />
              </Button>

              <Button
                size="icon"
                className={cn("h-14 w-14 rounded-full", isVideoOff ? "bg-red-500 hover:bg-red-600" : "bg-gray-600 hover:bg-gray-700")}
                onClick={toggleVideo}
              >
                {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Call ended / rejected toast-style banner */}
      <AnimatePresence>
        {(callStatus === 'ended' || callStatus === 'rejected') && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-16 left-0 right-0 mx-4 z-40 bg-secondary border border-border rounded-xl p-3 text-center shadow-lg"
          >
            <p className="text-sm font-medium">
              {callStatus === 'rejected' ? `${chatPartner} declined the call` : 'Call ended'}
            </p>
            {callStatus === 'ended' && (
              <p className="text-xs text-muted-foreground">Duration: {formattedDuration}</p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ChatWindow;
