// src/components/CallButton.tsx
// Drop this ANYWHERE in your chat UI — it auto-detects current user and remote user.
// Usage: just add <CallButton /> to your chat header or page. That's it.

import React from "react";
import CallFeature from "@/components/CallFeature";
import { useCallUsers } from "@/hooks/useCallUsers";

interface CallButtonProps {
  /** Override remote user if you already have it from the chat context */
  overrideRemoteId?: string;
  overrideRemoteName?: string;
  audioOnly?: boolean;
  className?: string;
}

export default function CallButton({
  overrideRemoteId,
  overrideRemoteName,
  audioOnly = false,
  className,
}: CallButtonProps) {
  const { currentUser, remoteUser, loading } = useCallUsers();

  if (loading || !currentUser) return null;

  const remoteId = overrideRemoteId ?? remoteUser?.id;
  const remoteName = overrideRemoteName ?? remoteUser?.name ?? "User";

  if (!remoteId) return null;

  return (
    <CallFeature
      currentUserId={currentUser.id}
      remoteUserId={remoteId}
      remoteUserName={remoteName}
      audioOnly={audioOnly}
      className={className}
    />
  );
}
