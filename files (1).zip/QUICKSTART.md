# 🚀 Quick Start Guide

Get your iHcab chat app running in 5 minutes!

## Step 1: Install Dependencies

```bash
cd ihcab-app
npm install firebase
npm install -D tailwindcss postcss autoprefixer
```

## Step 2: Copy Backend Files

Copy all files from the `firebase-backend` folder into your `ihcab-app` project:

```
firebase-backend/
├── src/                    → Copy to your src/
├── firestore.rules         → Copy to project root
├── firestore.indexes.json  → Copy to project root
├── vite.config.js         → Copy to project root (or merge if exists)
├── tailwind.config.js     → Copy to project root
├── postcss.config.js      → Copy to project root
└── index.html             → Copy to project root (or merge if exists)
```

## Step 3: Enable Phone Auth in Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/project/ihcab-app/authentication/providers)
2. Click on **Phone** provider
3. Click **Enable**
4. Click **Save**

## Step 4: Deploy Firestore Rules

```bash
# Login to Firebase
firebase login

# Initialize (if not already done)
firebase init firestore

# Deploy rules
firebase deploy --only firestore:rules
firebase deploy --only firestore:indexes
```

## Step 5: Run the App

```bash
npm run dev
```

Your app will open at `http://localhost:5173`

## Testing Phone Auth

### Option 1: Real Phone Number
- Use your actual phone number with country code: `+1234567890`
- Receive SMS with OTP code
- Enter the 6-digit code

### Option 2: Test Phone Numbers (No SMS)
1. In [Firebase Console](https://console.firebase.google.com/project/ihcab-app/authentication/providers)
2. Scroll to "Phone numbers for testing"
3. Add test numbers:
   - Phone: `+15555551234`
   - Code: `123456`
4. Use these credentials to test without SMS

## 🎉 That's It!

You now have a fully functional chat app with:
- ✅ Phone authentication (SMS OTP)
- ✅ Real-time messaging
- ✅ Online/offline status
- ✅ Unread message counts
- ✅ Responsive design

## Next Steps

- Read `SETUP.md` for detailed configuration
- Check `API_REFERENCE.md` for development docs
- Customize components in `src/components/`

## Troubleshooting

**Problem:** "reCAPTCHA verification failed"
- **Solution:** Clear cache or use incognito mode

**Problem:** Messages not updating in real-time
- **Solution:** Check Firestore rules are deployed

**Problem:** Can't find other users
- **Solution:** Ensure they've logged in at least once

## Support

Check the full `SETUP.md` guide for detailed troubleshooting and advanced configuration.
