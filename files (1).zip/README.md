# iHcab Chat App - Firebase Backend

Complete Firebase backend implementation for the iHcab React chat application with phone authentication, real-time messaging, and Firestore database.

## 📱 Features

- **Phone Authentication** - SMS OTP verification using Firebase Auth
- **Real-time Messaging** - Instant message delivery with Firestore
- **Online/Offline Status** - Live user presence tracking
- **Unread Counts** - Track unread messages per conversation
- **User Search** - Find users by phone number
- **Responsive Design** - Works on mobile and desktop
- **Security Rules** - Production-ready Firestore security
- **Type Safety** - Structured data models

## 🏗️ Project Structure

```
ihcab-app/
├── src/
│   ├── config/
│   │   └── firebase.js              # Firebase initialization
│   ├── services/
│   │   ├── authService.js           # Phone auth (OTP)
│   │   └── chatService.js           # Chat operations
│   ├── hooks/
│   │   ├── useAuth.js               # Auth React hooks
│   │   └── useChat.js               # Chat React hooks
│   ├── components/
│   │   ├── PhoneAuth.jsx            # Login UI
│   │   ├── ConversationsList.jsx   # Chat list
│   │   └── ChatInterface.jsx        # Message UI
│   ├── App.jsx                      # Main app
│   ├── main.jsx                     # Entry point
│   └── index.css                    # Styles
├── firestore.rules                  # Security rules
├── firestore.indexes.json           # Database indexes
├── package.json                     # Dependencies
└── vite.config.js                   # Build config
```

## 🚀 Quick Start

### Prerequisites
- Node.js v16+
- Firebase account (project: ihcab-app)
- Firebase CLI: `npm install -g firebase-tools`

### Installation

1. **Install dependencies**
   ```bash
   npm install firebase
   npm install -D tailwindcss postcss autoprefixer
   ```

2. **Copy backend files to your project**
   - All files from this package → your `ihcab-app/`

3. **Enable Phone Auth in Firebase Console**
   - Go to Authentication → Sign-in method
   - Enable Phone provider

4. **Deploy Firestore rules**
   ```bash
   firebase login
   firebase deploy --only firestore:rules
   firebase deploy --only firestore:indexes
   ```

5. **Run the app**
   ```bash
   npm run dev
   ```

📖 **See [QUICKSTART.md](./QUICKSTART.md) for detailed steps**

## 📚 Documentation

- **[QUICKSTART.md](./QUICKSTART.md)** - Get running in 5 minutes
- **[SETUP.md](./SETUP.md)** - Complete setup guide with troubleshooting
- **[API_REFERENCE.md](./API_REFERENCE.md)** - Full API documentation

## 🔐 Authentication Flow

```
1. User enters phone number (+1234567890)
2. Firebase sends SMS with OTP code
3. User enters 6-digit code
4. Firebase verifies and creates user session
5. User document created/updated in Firestore
```

## 💬 Chat Flow

```
1. User searches for recipient by phone number
2. Conversation created (or existing one retrieved)
3. Messages sent to Firestore in real-time
4. Both users receive updates via Firestore listeners
5. Unread counts updated automatically
```

## 🛠️ Tech Stack

- **React 18** - UI framework
- **Firebase Auth** - Phone authentication
- **Firestore** - Real-time database
- **Vite** - Build tool
- **Tailwind CSS** - Styling

## 🔒 Security

- **Firestore Rules** - Row-level security enforced
- **Authentication Required** - All operations require login
- **User Isolation** - Users can only access their own data
- **Message Privacy** - Only conversation participants can read messages

## 📊 Firestore Schema

### Users Collection
```javascript
/users/{userId}
{
  uid: string
  phoneNumber: string
  displayName: string
  photoURL: string | null
  status: "online" | "offline"
  lastSeen: Timestamp
  createdAt: Timestamp
  updatedAt: Timestamp
}
```

### Conversations Collection
```javascript
/conversations/{conversationId}
{
  participants: [userId1, userId2]
  lastMessage: string
  lastMessageTime: Timestamp
  unreadCount_userId1: number
  unreadCount_userId2: number
  createdAt: Timestamp
  updatedAt: Timestamp
}
```

### Messages Subcollection
```javascript
/conversations/{conversationId}/messages/{messageId}
{
  senderId: string
  text: string
  type: "text"
  createdAt: Timestamp
  read: boolean
  delivered: boolean
}
```

## 🎨 UI Components

### PhoneAuth Component
- Phone number input with validation
- OTP code verification
- Error handling
- Loading states

### ConversationsList Component
- Real-time conversation list
- Unread message badges
- Online/offline indicators
- User search functionality

### ChatInterface Component
- Real-time message updates
- Message bubbles (sent/received)
- Typing indicator
- Scroll to bottom on new messages

## 🔧 Configuration

### Firebase Config
Located in `src/config/firebase.js`:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyAWQwL8yDACesuv-YEKLN0G4BJ6TT7UrkI",
  authDomain: "ihcab-app.firebaseapp.com",
  projectId: "ihcab-app",
  // ... rest of config
};
```

### Environment Variables (Optional)
For production, use `.env.local`:
```env
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
# ... etc
```

## 🧪 Testing

### Test Phone Numbers
Add test numbers in Firebase Console for development:
- Phone: `+15555551234`
- OTP Code: `123456`

No SMS sent, instant verification!

### Real Phone Numbers
Use your actual phone number in production:
- Format: `+[country_code][phone_number]`
- Example: `+12345678901`

## 📈 Performance

- **Real-time Updates** - Firestore listeners for instant sync
- **Optimized Queries** - Indexed queries for fast retrieval
- **Lazy Loading** - Messages loaded on-demand
- **Unsubscribe Cleanup** - Prevent memory leaks

## 🚀 Deployment

### Firebase Hosting
```bash
firebase init hosting
npm run build
firebase deploy --only hosting
```

### Vercel/Netlify
```bash
npm run build
# Deploy dist/ folder
# Add environment variables in hosting platform
```

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| reCAPTCHA failed | Clear cache, try incognito mode |
| User not found | Ensure phone format includes country code |
| Messages not real-time | Check Firestore rules deployed |
| OTP not received | Verify Phone auth enabled, check quota |

📖 **See [SETUP.md](./SETUP.md) for detailed troubleshooting**

## 🔄 Updates & Maintenance

- **Security Rules** - Review and update regularly
- **Indexes** - Add as needed based on query errors
- **Dependencies** - Keep Firebase SDK updated
- **Usage Monitoring** - Check Firebase Console for quotas

## 📝 License

This is a backend implementation for the iHcab chat app. Use as needed for your project.

## 🤝 Contributing

To improve this backend:
1. Test thoroughly in development
2. Update documentation
3. Follow security best practices
4. Keep dependencies updated

## 📞 Support

For issues:
1. Check the documentation files
2. Review Firebase Console logs
3. Check browser console for errors
4. Verify all setup steps completed

## ✨ Next Steps

After setup:
- [ ] Customize UI components
- [ ] Add user profiles
- [ ] Implement group chats
- [ ] Add image/file sharing
- [ ] Add push notifications
- [ ] Implement message search

## 🎯 Key Files

| File | Purpose |
|------|---------|
| `QUICKSTART.md` | 5-minute setup guide |
| `SETUP.md` | Complete setup & troubleshooting |
| `API_REFERENCE.md` | Full API documentation |
| `firestore.rules` | Security rules |
| `firestore.indexes.json` | Database indexes |

---

**Built with ❤️ using Firebase & React**
