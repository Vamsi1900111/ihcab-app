// src/hooks/useWebRTCCall.ts
// Drop-in hook for real-time WhatsApp-style calls using WebRTC + Supabase Realtime

import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { RealtimeChannel } from "@supabase/supabase-js";

export type CallStatus =
  | "idle"
  | "calling"
  | "ringing"
  | "active"
  | "ended"
  | "rejected"
  | "error";

interface UseWebRTCCallProps {
  currentUserId: string;
  remoteUserId: string;
  localVideoRef: React.RefObject<HTMLVideoElement>;
  remoteVideoRef: React.RefObject<HTMLVideoElement>;
  audioOnly?: boolean;
}

// STUN servers for NAT traversal (Google's public STUN servers)
const ICE_SERVERS = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:stun2.l.google.com:19302" },
  ],
};

export function useWebRTCCall({
  currentUserId,
  remoteUserId,
  localVideoRef,
  remoteVideoRef,
  audioOnly = false,
}: UseWebRTCCallProps) {
  const [callStatus, setCallStatus] = useState<CallStatus>("idle");
  const [callId, setCallId] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(audioOnly);
  const [callDuration, setCallDuration] = useState(0);

  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const durationTimerRef = useRef<NodeJS.Timeout | null>(null);
  const callIdRef = useRef<string | null>(null);

  // ─── Cleanup helper ──────────────────────────────────────────────────────
  const cleanup = useCallback(() => {
    if (durationTimerRef.current) {
      clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
    if (remoteVideoRef.current) remoteVideoRef.current.srcObject = null;

    setCallDuration(0);
    callIdRef.current = null;
    setCallId(null);
  }, [localVideoRef, remoteVideoRef]);

  // ─── Get local media ─────────────────────────────────────────────────────
  const getLocalStream = useCallback(async (): Promise<MediaStream> => {
    const constraints: MediaStreamConstraints = audioOnly
      ? { audio: true, video: false }
      : { audio: true, video: { width: 1280, height: 720, facingMode: "user" } };

    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    localStreamRef.current = stream;
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = stream;
      localVideoRef.current.muted = true; // Don't play back own audio
    }
    return stream;
  }, [audioOnly, localVideoRef]);

  // ─── Create peer connection ───────────────────────────────────────────────
  const createPeerConnection = useCallback(
    (cId: string, stream: MediaStream) => {
      const pc = new RTCPeerConnection(ICE_SERVERS);
      peerConnectionRef.current = pc;

      // Add local tracks
      stream.getTracks().forEach((track) => {
        pc.addTrack(track, stream);
      });

      // When remote track arrives, attach to remote video
      pc.ontrack = (event) => {
        if (remoteVideoRef.current && event.streams[0]) {
          remoteVideoRef.current.srcObject = event.streams[0];
        }
      };

      // Send ICE candidates to Supabase
      pc.onicecandidate = async (event) => {
        if (event.candidate && cId) {
          await supabase.from("call_ice_candidates").insert({
            call_id: cId,
            sender_id: currentUserId,
            candidate: event.candidate.toJSON(),
          });
        }
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected") {
          setCallStatus("active");
          durationTimerRef.current = setInterval(() => {
            setCallDuration((d) => d + 1);
          }, 1000);
        } else if (
          pc.connectionState === "disconnected" ||
          pc.connectionState === "failed" ||
          pc.connectionState === "closed"
        ) {
          setCallStatus("ended");
          cleanup();
        }
      };

      return pc;
    },
    [currentUserId, remoteVideoRef, cleanup]
  );

  // ─── Subscribe to signaling channel ─────────────────────────────────────
  const subscribeToSignaling = useCallback(
    (cId: string) => {
      const channel = supabase
        .channel(`call:${cId}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "call_sessions",
            filter: `id=eq.${cId}`,
          },
          async (payload) => {
            const session = payload.new as {
              status: string;
              answer_sdp?: string;
            };

            // Caller receives answer
            if (
              session.status === "active" &&
              session.answer_sdp &&
              peerConnectionRef.current &&
              peerConnectionRef.current.signalingState !== "stable"
            ) {
              const answer = new RTCSessionDescription({
                type: "answer",
                sdp: session.answer_sdp,
              });
              await peerConnectionRef.current.setRemoteDescription(answer);
            }

            if (session.status === "rejected") {
              setCallStatus("rejected");
              cleanup();
            }

            if (session.status === "ended") {
              setCallStatus("ended");
              cleanup();
            }
          }
        )
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "call_ice_candidates",
            filter: `call_id=eq.${cId}`,
          },
          async (payload) => {
            const row = payload.new as {
              sender_id: string;
              candidate: RTCIceCandidateInit;
            };
            // Only apply candidates from the remote peer
            if (row.sender_id !== currentUserId && peerConnectionRef.current) {
              try {
                await peerConnectionRef.current.addIceCandidate(
                  new RTCIceCandidate(row.candidate)
                );
              } catch (e) {
                console.warn("ICE candidate error:", e);
              }
            }
          }
        )
        .subscribe();

      channelRef.current = channel;
    },
    [currentUserId, cleanup]
  );

  // ─── Listen for incoming calls ────────────────────────────────────────────
  useEffect(() => {
    const incomingChannel = supabase
      .channel(`incoming:${currentUserId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "call_sessions",
          filter: `receiver_id=eq.${currentUserId}`,
        },
        async (payload) => {
          const session = payload.new as {
            id: string;
            caller_id: string;
            status: string;
            offer_sdp: string;
          };

          if (
            session.status === "pending" &&
            session.caller_id === remoteUserId
          ) {
            callIdRef.current = session.id;
            setCallId(session.id);
            setCallStatus("ringing");
            subscribeToSignaling(session.id);

            // ─── Auto-answer handler (stored in window for CallUI to trigger)
            (window as any).__pendingCallSession = session;
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(incomingChannel);
    };
  }, [currentUserId, remoteUserId, subscribeToSignaling]);

  // ─── Start Call (Caller side) ─────────────────────────────────────────────
  const startCall = useCallback(async () => {
    try {
      setCallStatus("calling");
      const stream = await getLocalStream();

      // Create session in DB
      const { data, error } = await supabase
        .from("call_sessions")
        .insert({
          caller_id: currentUserId,
          receiver_id: remoteUserId,
          status: "pending",
        })
        .select()
        .single();

      if (error || !data) throw new Error(error?.message || "Failed to create call");

      const cId = data.id;
      callIdRef.current = cId;
      setCallId(cId);

      const pc = createPeerConnection(cId, stream);
      subscribeToSignaling(cId);

      // Create offer
      const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: !audioOnly });
      await pc.setLocalDescription(offer);

      // Save offer to DB
      await supabase
        .from("call_sessions")
        .update({
          offer_sdp: offer.sdp,
          status: "ringing",
        })
        .eq("id", cId);
    } catch (err) {
      console.error("startCall error:", err);
      setCallStatus("error");
      cleanup();
    }
  }, [
    currentUserId,
    remoteUserId,
    audioOnly,
    getLocalStream,
    createPeerConnection,
    subscribeToSignaling,
    cleanup,
  ]);

  // ─── Answer Call (Receiver side) ──────────────────────────────────────────
  const answerCall = useCallback(async () => {
    const session = (window as any).__pendingCallSession;
    if (!session) return;

    try {
      const stream = await getLocalStream();
      const pc = createPeerConnection(session.id, stream);

      // Set remote description (caller's offer)
      const offer = new RTCSessionDescription({
        type: "offer",
        sdp: session.offer_sdp,
      });
      await pc.setRemoteDescription(offer);

      // Create answer
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      // Save answer to DB
      await supabase
        .from("call_sessions")
        .update({
          answer_sdp: answer.sdp,
          status: "active",
        })
        .eq("id", session.id);

      setCallStatus("active");
      delete (window as any).__pendingCallSession;
    } catch (err) {
      console.error("answerCall error:", err);
      setCallStatus("error");
      cleanup();
    }
  }, [getLocalStream, createPeerConnection, cleanup]);

  // ─── Reject Call ──────────────────────────────────────────────────────────
  const rejectCall = useCallback(async () => {
    const cId = callIdRef.current;
    if (cId) {
      await supabase
        .from("call_sessions")
        .update({ status: "rejected" })
        .eq("id", cId);
    }
    delete (window as any).__pendingCallSession;
    setCallStatus("idle");
    cleanup();
  }, [cleanup]);

  // ─── End Call ────────────────────────────────────────────────────────────
  const endCall = useCallback(async () => {
    const cId = callIdRef.current;
    if (cId) {
      await supabase
        .from("call_sessions")
        .update({ status: "ended" })
        .eq("id", cId);
    }
    setCallStatus("ended");
    cleanup();
    setTimeout(() => setCallStatus("idle"), 1500);
  }, [cleanup]);

  // ─── Toggle Mute ─────────────────────────────────────────────────────────
  const toggleMute = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = !t.enabled;
      });
      setIsMuted((m) => !m);
    }
  }, []);

  // ─── Toggle Video ─────────────────────────────────────────────────────────
  const toggleVideo = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((t) => {
        t.enabled = !t.enabled;
      });
      setIsVideoOff((v) => !v);
    }
  }, []);

  // Format duration as mm:ss
  const formattedDuration = `${String(Math.floor(callDuration / 60)).padStart(2, "0")}:${String(callDuration % 60).padStart(2, "0")}`;

  return {
    callStatus,
    callId,
    isMuted,
    isVideoOff,
    formattedDuration,
    startCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
  };
}
