// src/components/CallFeature.tsx
// WhatsApp-style real-time call component
// Usage: <CallFeature currentUserId="vamsi" remoteUserId="bhavya" remoteUserName="Bhavya" />

import React, { useRef } from "react";
import {
  Phone,
  PhoneOff,
  PhoneIncoming,
  Mic,
  MicOff,
  Video,
  VideoOff,
  X,
} from "lucide-react";
import { useWebRTCCall } from "@/hooks/useWebRTCCall";
import { cn } from "@/lib/utils";

interface CallFeatureProps {
  currentUserId: string;
  remoteUserId: string;
  remoteUserName?: string;
  audioOnly?: boolean;
  className?: string;
}

export default function CallFeature({
  currentUserId,
  remoteUserId,
  remoteUserName = remoteUserId,
  audioOnly = false,
  className,
}: CallFeatureProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  const {
    callStatus,
    isMuted,
    isVideoOff,
    formattedDuration,
    startCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
  } = useWebRTCCall({
    currentUserId,
    remoteUserId,
    localVideoRef,
    remoteVideoRef,
    audioOnly,
  });

  // ─── Call Button (idle state — shown in chat header) ─────────────────────
  if (callStatus === "idle") {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        {/* Audio call button */}
        <button
          onClick={startCall}
          className="p-2 rounded-full bg-green-500 hover:bg-green-600 text-white transition-colors shadow"
          title="Voice Call"
        >
          <Phone size={18} />
        </button>
        {/* Video call button */}
        {!audioOnly && (
          <button
            onClick={() => startCall()}
            className="p-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white transition-colors shadow"
            title="Video Call"
          >
            <Video size={18} />
          </button>
        )}
      </div>
    );
  }

  // ─── Incoming Call (ringing state) ────────────────────────────────────────
  if (callStatus === "ringing") {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
        <div className="bg-gray-900 rounded-2xl p-8 text-center shadow-2xl max-w-xs w-full mx-4 animate-bounce-in">
          {/* Pulsing ring animation */}
          <div className="relative mx-auto w-24 h-24 mb-6">
            <span className="absolute inset-0 rounded-full bg-green-500/30 animate-ping" />
            <span className="absolute inset-2 rounded-full bg-green-500/50 animate-ping animation-delay-150" />
            <div className="relative z-10 w-24 h-24 rounded-full bg-green-600 flex items-center justify-center">
              <PhoneIncoming size={36} className="text-white" />
            </div>
          </div>

          <p className="text-gray-400 text-sm mb-1">Incoming call from</p>
          <h2 className="text-white text-2xl font-bold mb-6">{remoteUserName}</h2>

          <div className="flex justify-center gap-8">
            {/* Reject */}
            <button
              onClick={rejectCall}
              className="flex flex-col items-center gap-2 p-4 rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors shadow-lg"
            >
              <X size={28} />
              <span className="text-xs">Decline</span>
            </button>
            {/* Answer */}
            <button
              onClick={answerCall}
              className="flex flex-col items-center gap-2 p-4 rounded-full bg-green-500 hover:bg-green-600 text-white transition-colors shadow-lg animate-pulse"
            >
              <Phone size={28} />
              <span className="text-xs">Answer</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ─── Outgoing Call (calling state) ───────────────────────────────────────
  if (callStatus === "calling") {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
        <div className="bg-gray-900 rounded-2xl p-8 text-center shadow-2xl max-w-xs w-full mx-4">
          <div className="relative mx-auto w-24 h-24 mb-6">
            <span className="absolute inset-0 rounded-full bg-blue-500/30 animate-ping" />
            <div className="relative z-10 w-24 h-24 rounded-full bg-blue-600 flex items-center justify-center">
              <Phone size={36} className="text-white" />
            </div>
          </div>
          <h2 className="text-white text-2xl font-bold mb-2">{remoteUserName}</h2>
          <p className="text-gray-400 mb-8 animate-pulse">Calling...</p>
          <button
            onClick={endCall}
            className="p-4 rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors shadow-lg"
          >
            <PhoneOff size={28} />
          </button>
        </div>
      </div>
    );
  }

  // ─── Active Call (video or audio) ────────────────────────────────────────
  if (callStatus === "active") {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col">
        {/* Remote video (full screen) */}
        {!audioOnly ? (
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className="flex-1 w-full object-cover"
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-900">
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-700 flex items-center justify-center mx-auto mb-4">
                <span className="text-5xl">👤</span>
              </div>
              <h2 className="text-white text-2xl font-bold">{remoteUserName}</h2>
              <p className="text-gray-400 mt-2">{formattedDuration}</p>
            </div>
          </div>
        )}

        {/* Local video (picture-in-picture) */}
        {!audioOnly && (
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="absolute top-4 right-4 w-28 h-40 rounded-xl object-cover border-2 border-white shadow-xl"
          />
        )}

        {/* Call duration */}
        {!audioOnly && (
          <div className="absolute top-4 left-4 bg-black/50 rounded-full px-3 py-1">
            <span className="text-white text-sm font-mono">{formattedDuration}</span>
          </div>
        )}

        {/* Controls bar */}
        <div className="absolute bottom-10 left-0 right-0 flex justify-center gap-6">
          {/* Mute */}
          <button
            onClick={toggleMute}
            className={cn(
              "p-4 rounded-full text-white transition-colors shadow-lg",
              isMuted ? "bg-red-500 hover:bg-red-600" : "bg-gray-600 hover:bg-gray-700"
            )}
          >
            {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
          </button>

          {/* End Call */}
          <button
            onClick={endCall}
            className="p-5 rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors shadow-xl"
          >
            <PhoneOff size={28} />
          </button>

          {/* Toggle Video */}
          {!audioOnly && (
            <button
              onClick={toggleVideo}
              className={cn(
                "p-4 rounded-full text-white transition-colors shadow-lg",
                isVideoOff ? "bg-red-500 hover:bg-red-600" : "bg-gray-600 hover:bg-gray-700"
              )}
            >
              {isVideoOff ? <VideoOff size={24} /> : <Video size={24} />}
            </button>
          )}
        </div>
      </div>
    );
  }

  // ─── Call ended / rejected / error ───────────────────────────────────────
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="bg-gray-900 rounded-2xl p-8 text-center shadow-2xl max-w-xs w-full mx-4">
        <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center mx-auto mb-4">
          <PhoneOff size={32} className="text-gray-400" />
        </div>
        <h2 className="text-white text-xl font-bold mb-2">
          {callStatus === "rejected" ? "Call Declined" : callStatus === "error" ? "Call Failed" : "Call Ended"}
        </h2>
        <p className="text-gray-400 text-sm">
          {callStatus === "rejected"
            ? `${remoteUserName} declined the call`
            : callStatus === "error"
            ? "Connection failed. Try again."
            : `Duration: ${formattedDuration}`}
        </p>
      </div>
    </div>
  );
}
