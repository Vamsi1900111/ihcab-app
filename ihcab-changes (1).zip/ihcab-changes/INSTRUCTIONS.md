# iHcab App — Change Instructions
## Summary of 3 changes + exact file locations

---

## ✅ CHANGE 1: Remove Lovable Icon from Browser Tab

**File to replace:** `index.html` (root of repo)

Replace the entire `index.html` with the provided `index.html` file.

**What it does:** Replaces the Lovable favicon with a 🚖 emoji favicon, so the browser tab shows "iHcab" with a cab icon instead of the Lovable logo.

---

## ✅ CHANGE 2: Real-time WhatsApp-style Calls

### Step A — Run the SQL Migration
Go to your **Supabase Dashboard → SQL Editor** and run:
```
supabase/migrations/20250326_add_calls_and_email_tracking.sql
```

### Step B — Add the hook file
Create this new file in your repo:
```
src/hooks/useWebRTCCall.ts
```
(copy the provided `useWebRTCCall.ts`)

### Step C — Add the component file
Create this new file in your repo:
```
src/components/CallFeature.tsx
```
(copy the provided `CallFeature.tsx`)

### Step D — Add to your Chat Header
Find your chat header component (likely `src/components/ChatHeader.tsx` or similar).
Import and add `<CallFeature>`:

```tsx
import CallFeature from "@/components/CallFeature";

// Inside your chat header JSX, add this next to the user name:
<CallFeature
  currentUserId="vamsi"        // or use the logged-in user's ID from auth
  remoteUserId="bhavya"       // or use the other user's ID
  remoteUserName="Bhavya"
  audioOnly={false}            // set true for audio-only
/>
```

**How it works:**
- Uses WebRTC for peer-to-peer audio/video (just like WhatsApp)
- Uses Supabase Realtime as the signaling channel (no extra server needed)
- Shows incoming call screen with Accept/Decline buttons
- Shows video call with mute/video toggle controls

---

## ✅ CHANGE 3: Email Notification for Unread Messages

### Step A — Run the SQL migration (same file as above — already adds `read_at` and `email_notified` columns)

### Step B — Deploy the Edge Function
From your terminal in the project root:
```bash
npx supabase functions deploy check-unread-messages
```

### Step C — Set up the cron job
1. Go to **Supabase Dashboard → Database → Extensions**
2. Enable **pg_cron**
3. Go to **SQL Editor** and run `SETUP_CRON_JOB.sql`
   - Replace `YOUR_SUPABASE_PROJECT_REF` with your project ref
   - Replace `YOUR_ANON_KEY` with your anon key (from Settings → API)

### Step D — Mark messages as read when Vamsi views them
Find where you render messages in your chat component and add a read receipt call:

```ts
// When Vamsi's messages load/become visible
await supabase
  .from('messages')
  .update({ read_at: new Date().toISOString() })
  .eq('id', message.id)
  .is('read_at', null);
```

**How it works:**
- Every 1 minute, the Edge Function checks for messages from Bhavya to Vamsi
- If any message is unread (no `read_at`) AND was sent >1 minute ago AND hasn't been emailed yet
- It sends an email from `vamsikumar3u@gmail.com` to `vamsikrishnakumar.g@gmail.com`
- The email contains the message preview + a link to open the app

---

## File Placement Summary

```
ihcab-app/
├── index.html                                          ← REPLACE THIS
├── src/
│   ├── components/
│   │   └── CallFeature.tsx                             ← ADD THIS (new file)
│   └── hooks/
│       └── useWebRTCCall.ts                            ← ADD THIS (new file)
└── supabase/
    ├── functions/
    │   └── check-unread-messages/
    │       └── index.ts                                ← ADD THIS (new file)
    └── migrations/
        ├── 20250326_add_calls_and_email_tracking.sql   ← RUN IN SQL EDITOR
        └── SETUP_CRON_JOB.sql                          ← RUN IN SQL EDITOR
```

---

## Notes

- The Gmail App Password `deoy qqnj mcqz ppnz` is embedded in the Edge Function — it is stored server-side in Supabase and never exposed to the client browser.
- For production, move the app password to a **Supabase Secret**: `supabase secrets set GMAIL_APP_PASSWORD="deoy qqnj mcqz ppnz"` and read it with `Deno.env.get("GMAIL_APP_PASSWORD")`.
- The WebRTC call uses Google's public STUN servers — no paid TURN server is needed for most networks. If calls fail on strict corporate networks, consider adding a TURN server from Twilio or Metered.
