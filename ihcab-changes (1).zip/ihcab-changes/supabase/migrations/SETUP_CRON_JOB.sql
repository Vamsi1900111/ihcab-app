-- ═══════════════════════════════════════════════════════════════════
-- SUPABASE SETUP INSTRUCTIONS FOR iHcab EMAIL NOTIFICATIONS
-- Run these in your Supabase SQL Editor (Dashboard > SQL Editor)
-- ═══════════════════════════════════════════════════════════════════

-- STEP 1: Enable pg_cron extension (needed for scheduling)
-- Go to: Supabase Dashboard > Database > Extensions > search "pg_cron" > Enable

-- STEP 2: Schedule the function to run every minute
-- Replace YOUR_SUPABASE_PROJECT_REF with your actual project ref (e.g. abcdefghijklmnop)
-- Find it in: Supabase Dashboard > Settings > General > Reference ID

SELECT cron.schedule(
  'check-unread-messages-every-minute',
  '* * * * *',  -- every minute
  $$
  SELECT net.http_post(
    url := 'https://YOUR_SUPABASE_PROJECT_REF.supabase.co/functions/v1/check-unread-messages',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer YOUR_ANON_KEY"}'::jsonb,
    body := '{}'::jsonb
  ) AS request_id;
  $$
);

-- STEP 3: Verify cron job was created
SELECT * FROM cron.job;

-- ─── To remove/update the cron job ────────────────────────────────────────
-- SELECT cron.unschedule('check-unread-messages-every-minute');


-- ═══════════════════════════════════════════════════════════════════
-- MARK MESSAGES AS READ — add this to your ChatMessage component
-- When Vamsi opens/views a message, call this:
-- ═══════════════════════════════════════════════════════════════════
-- UPDATE messages SET read_at = NOW() WHERE id = :messageId AND read_at IS NULL;

-- ─── Or in Supabase JS client ──────────────────────────────────────────────
-- await supabase
--   .from('messages')
--   .update({ read_at: new Date().toISOString() })
--   .eq('id', messageId)
--   .is('read_at', null);
