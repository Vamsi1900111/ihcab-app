-- Migration: add_call_sessions_and_message_read_tracking
-- Run this in your Supabase SQL Editor

-- ─── CALL SESSIONS TABLE ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.call_sessions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  caller_id     TEXT NOT NULL,
  receiver_id   TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'pending',
  -- status: 'pending' | 'ringing' | 'active' | 'ended' | 'rejected'
  offer_sdp     TEXT,
  answer_sdp    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ICE candidates table (separate for efficiency)
CREATE TABLE IF NOT EXISTS public.call_ice_candidates (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id       UUID NOT NULL REFERENCES public.call_sessions(id) ON DELETE CASCADE,
  sender_id     TEXT NOT NULL,
  candidate     JSONB NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MESSAGES READ TRACKING ───────────────────────────────────────────────────
-- Add read_at column to messages if it doesn't exist
-- (Skip this if your messages table already has it)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'read_at'
  ) THEN
    ALTER TABLE public.messages ADD COLUMN read_at TIMESTAMPTZ;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'email_notified'
  ) THEN
    ALTER TABLE public.messages ADD COLUMN email_notified BOOLEAN DEFAULT FALSE;
  END IF;
END $$;

-- ─── REALTIME ENABLE ─────────────────────────────────────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE public.call_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.call_ice_candidates;

-- ─── RLS POLICIES ────────────────────────────────────────────────────────────
ALTER TABLE public.call_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.call_ice_candidates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all for call_sessions" ON public.call_sessions
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow all for call_ice_candidates" ON public.call_ice_candidates
  FOR ALL USING (true) WITH CHECK (true);
