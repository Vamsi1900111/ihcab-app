// supabase/functions/check-unread-messages/index.ts
// Deploy with: supabase functions deploy check-unread-messages
// Schedule with pg_cron every 1 min (see instructions below)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

// Gmail SMTP via fetch (using Gmail API or SMTP relay)
// We use Gmail's SMTP via nodemailer-style approach with fetch
const SMTP_USER = "vamsikumar3u@gmail.com";
const SMTP_APP_PASSWORD = "deoy qqnj mcqz ppnz"; // Gmail App Password
const RECIPIENT_EMAIL = "vamsikrishnakumar.g@gmail.com";

// ─── Send email via Gmail SMTP relay ─────────────────────────────────────────
async function sendEmail(subject: string, body: string): Promise<boolean> {
  // Using Gmail's SMTP via fetch with basic auth (base64)
  // Deno supports TCP but we use Gmail's web API approach via OAuth isn't available here,
  // so we use an SMTP-over-HTTP relay approach.
  // Best approach in Supabase Edge: use the smtp library via Deno

  try {
    // Use SMTP directly via Deno's TCP (smtp npm package ported to Deno)
    const { SMTPClient } = await import("https://deno.land/x/denomailer@1.6.0/mod.ts");

    const client = new SMTPClient({
      connection: {
        hostname: "smtp.gmail.com",
        port: 465,
        tls: true,
        auth: {
          username: SMTP_USER,
          password: SMTP_APP_PASSWORD,
        },
      },
    });

    await client.send({
      from: SMTP_USER,
      to: RECIPIENT_EMAIL,
      subject: subject,
      content: body,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: #1a1a2e; padding: 20px; border-radius: 8px 8px 0 0;">
            <h2 style="color: #e94560; margin: 0;">🚖 iHcab — New Message</h2>
          </div>
          <div style="background: #f8f9fa; padding: 20px; border-radius: 0 0 8px 8px; border: 1px solid #dee2e6;">
            <p style="color: #333; font-size: 16px;">${body}</p>
            <hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;" />
            <p style="color: #888; font-size: 12px;">
              This notification was sent because a message went unread for over 1 minute.<br/>
              Open the app to read it: <a href="https://ihcab-app.lovable.app">ihcab-app.lovable.app</a>
            </p>
          </div>
        </div>
      `,
    });

    await client.close();
    return true;
  } catch (err) {
    console.error("SMTP error:", err);
    return false;
  }
}

// ─── Main handler ─────────────────────────────────────────────────────────────
Deno.serve(async (_req) => {
  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

    // Find messages from bhavya to vamsi that:
    // 1. Are unread (read_at IS NULL)
    // 2. Were sent more than 1 minute ago
    // 3. Haven't been notified yet
    const oneMinuteAgo = new Date(Date.now() - 60 * 1000).toISOString();

    const { data: unreadMessages, error } = await supabase
      .from("messages")
      .select("id, content, created_at, sender_id, receiver_id")
      .or("sender_id.eq.bhavya,sender_id.ilike.%bhavya%")
      .or("receiver_id.eq.vamsi,receiver_id.ilike.%vamsi%")
      .is("read_at", null)
      .eq("email_notified", false)
      .lt("created_at", oneMinuteAgo)
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Query error:", error);

      // Fallback: try without sender/receiver filter (find any unread)
      const { data: fallbackMessages, error: fallbackError } = await supabase
        .from("messages")
        .select("id, content, created_at, sender_id, receiver_id")
        .is("read_at", null)
        .eq("email_notified", false)
        .lt("created_at", oneMinuteAgo);

      if (fallbackError) {
        return new Response(
          JSON.stringify({ error: fallbackError.message }),
          { status: 500 }
        );
      }

      // Filter in JS for bhavya -> vamsi messages
      const filtered = (fallbackMessages || []).filter((msg) => {
        const sender = (msg.sender_id || "").toLowerCase();
        const receiver = (msg.receiver_id || "").toLowerCase();
        return sender.includes("bhavya") && receiver.includes("vamsi");
      });

      if (filtered.length === 0) {
        return new Response(JSON.stringify({ checked: true, notified: 0 }), {
          status: 200,
        });
      }

      // Send one consolidated email for all unread
      const count = filtered.length;
      const latestMsg = filtered[filtered.length - 1];
      const subject = `📩 iHcab: You have ${count} unread message${count > 1 ? "s" : ""} from Bhavya`;
      const body = count === 1
        ? `Bhavya sent you a message and it's still unread: "${latestMsg.content}"`
        : `Bhavya sent you ${count} messages that are still unread. Latest: "${latestMsg.content}"`;

      const sent = await sendEmail(subject, body);

      if (sent) {
        // Mark as notified
        const ids = filtered.map((m) => m.id);
        await supabase
          .from("messages")
          .update({ email_notified: true })
          .in("id", ids);
      }

      return new Response(
        JSON.stringify({ checked: true, notified: sent ? count : 0 }),
        { status: 200 }
      );
    }

    if (!unreadMessages || unreadMessages.length === 0) {
      return new Response(JSON.stringify({ checked: true, notified: 0 }), {
        status: 200,
      });
    }

    const count = unreadMessages.length;
    const latestMsg = unreadMessages[unreadMessages.length - 1];
    const subject = `📩 iHcab: You have ${count} unread message${count > 1 ? "s" : ""} from Bhavya`;
    const body = count === 1
      ? `Bhavya sent you a message and it's been over 1 minute unread: "${latestMsg.content}"`
      : `Bhavya sent you ${count} messages that are still unread after 1 minute. Latest: "${latestMsg.content}"`;

    const sent = await sendEmail(subject, body);

    if (sent) {
      const ids = unreadMessages.map((m) => m.id);
      await supabase
        .from("messages")
        .update({ email_notified: true })
        .in("id", ids);
    }

    return new Response(
      JSON.stringify({ checked: true, notified: sent ? count : 0 }),
      { status: 200 }
    );
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
    });
  }
});
